/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javame.example;

import java.util.Timer;
import javax.microedition.midlet.MIDlet;

/**
 *
 * @author biswajyoti.dutta
 */
public class TimerTask extends MIDlet {
    
    private Timer timer;
    private MyTask task;
    
    @Override
    public void startApp() {
        System.out.println("TimerTask application started...");
        timer = new Timer();
        task = new MyTask();
        //the task mentioned in the MyTask class will be performed, without any delay (as the second argument is 0)
        //after every 2 seconds (since third argument passed is 2000)
        timer.schedule(task, 0, 2000);
    }
    
    @Override
    public void destroyApp(boolean unconditional) {
        System.out.println("TimerTask application stopped...");
        task.cancel();
    }
}
