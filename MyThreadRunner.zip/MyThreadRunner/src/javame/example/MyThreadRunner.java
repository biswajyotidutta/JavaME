/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javame.example;

import javax.microedition.midlet.MIDlet;

/**
 *
 * @author biswajyoti.dutta
 */
public class MyThreadRunner extends MIDlet {
    
    private MyThread myThread;
    
    @Override
    public void startApp() {
        System.out.println("MyThreadRunner application started...");
        myThread = new MyThread();
        myThread.start();
    }
    
    @Override
    public void destroyApp(boolean unconditional) {
        System.out.println("MyThreadRunner Application stopped...");
        myThread.stop();
    }
}
