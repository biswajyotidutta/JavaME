/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javame.example;

/**
 *
 * @author biswajyoti.dutta
 */
public class MyThread extends Thread {

    private volatile boolean shouldRun = true;
    
    @Override
    public void run() {
       while(shouldRun) {
           try {
               System.out.println("Running MyThread...");
               sleep(2000);
           } catch (InterruptedException ex) {
               ex.printStackTrace();
           }
       }
    }
    
    public void stop() {
        shouldRun = false;
        interrupt();
    }
}
