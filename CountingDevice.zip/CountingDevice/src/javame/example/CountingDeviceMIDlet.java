/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javame.example;

import javax.microedition.midlet.MIDlet;

/**
 *
 * @author biswajyoti.dutta
 */
public class CountingDeviceMIDlet extends MIDlet implements CountListener {

    private CountingDevice device;
    
    @Override
    public void startApp() {
        System.out.println("CountingDevice application started....");
        device = new CountingDevice(0, 5, 10);
        device.addCountListener(this);
        device.start();
    }
    
    @Override
    public void destroyApp(boolean unconditional) {
        System.out.println("CountingDevice application stopped....");
        device.stop();
    }

    @Override
    public void countReached(int count) {
        System.out.println("In CountingDevice application IMlet :: Count reached : " +count);
    }
    
}
