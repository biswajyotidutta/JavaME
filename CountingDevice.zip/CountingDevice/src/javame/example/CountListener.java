/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javame.example;

/**
 *
 * @author biswajyoti.dutta
 */
public interface CountListener {
    
    /**
     * This method is used to implement the business logic when the count is reached.
     * @param count
     */
    public void countReached(int count);
}
