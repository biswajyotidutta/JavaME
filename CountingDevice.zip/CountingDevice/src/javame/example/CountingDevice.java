/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javame.example;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author biswajyoti.dutta
 */
public class CountingDevice extends Thread {
  
    private final int trigger;
    private final int lowerLimit;
    private final int upperLimit;
    private volatile boolean shouldRun = true;
    private volatile int count;
    private volatile List<CountListener> countListeners;
    
    public CountingDevice(int lowerLimit, int trigger, int upperLimit) {
        this.lowerLimit = lowerLimit;
        this.trigger = trigger;
        this.upperLimit = upperLimit;
        this.countListeners = new ArrayList<>();
    }
    
    public void addCountListener(CountListener countListener){
        countListeners.add(countListener);
    }
    
    @Override
    public void run() {
       count = lowerLimit;
       while (shouldRun) {
           System.out.println("count = "+count);
           if(count == trigger) {
               for (CountListener countListener : countListeners) {
                   countListener.countReached(count);
               }
           }
           if (count == upperLimit) {
               count = lowerLimit;
           } else {
               count++;
           }
           try {
               sleep(2000);
           } catch (InterruptedException ex) {
               
           }
       }
    }
    
    public void stop() {
        shouldRun = false;
        interrupt();
    }
}
