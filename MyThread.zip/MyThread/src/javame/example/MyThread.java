/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javame.example;

import static java.lang.Thread.sleep;
import javax.microedition.midlet.MIDlet;

/**
 *
 * @author biswajyoti.dutta
 */
public class MyThread extends MIDlet implements Runnable {
    private boolean shouldRun = true;
    private Thread myThread;
    
    @Override
    public void startApp() {
        System.out.println("MyThread application started...");
        myThread = new Thread(this);
        myThread.start();
    }
    
    @Override
    public void destroyApp(boolean unconditional) {
        System.out.println("MyThread Application stopped...");
        shouldRun = false;
        myThread.interrupt();
    }

    @Override
    public void run() {
        while(shouldRun) {
           try {
               System.out.println("MyThread is running...");
               sleep(2000);
           } catch (InterruptedException ex) {
             ex.printStackTrace();
           }
        }
    }
}
