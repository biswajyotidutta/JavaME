/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example;

import javax.microedition.midlet.MIDlet;

/**
 *
 * @author biswajyoti.dutta
 */
public class HelloWorld extends MIDlet {
    private boolean shouldRun = true;
    
    @Override
    public void startApp() {
        System.out.println("Application started... In startApp()");
        System.out.println("Hello World");            
    }
    
    @Override
    public void destroyApp(boolean unconditional) {
        System.out.println("Application stopped... In destroyApp()");
        shouldRun = false;
    }
}
